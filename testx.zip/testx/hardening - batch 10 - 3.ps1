# Enlarge Windows Event Security Log Size
$LogSizes = @{
    'Security' = 1024000
    'Application' = 1024000
    'System' = 1024000
    'Windows Powershell' = 1024000
    'Microsoft-Windows-PowerShell/Operational' = 1024000
}

foreach ($LogName in $LogSizes.Keys) {
    wevtutil sl $LogName "/ms:$($LogSizes[$LogName])"
}

# Record command line data in process creation events eventid 4688
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" -Name "ProcessCreationIncludeCmdLine_Enabled" -Value 1 -PropertyType DWORD -Force | Out-Null

# Enable Advanced Settings
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SCENoApplyLegacyAuditPolicy" -Value 1 -PropertyType DWORD -Force | Out-Null

# Enable PowerShell Logging
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name "EnableScriptBlockLogging" -Value 1 -PropertyType DWORD -Force | Out-Null

