# Encryption - Cipher Suites (order) - All cipher included to avoid application problems
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002" -Name Functions -Value "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_GCM_SHA384,TLS_RSA_WITH_AES_128_GCM_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_AES_256_GCM_SHA384,TLS_AES_128_GCM_SHA256,TLS_DHE_RSA_WITH_AES_256_GCM_SHA384,TLS_DHE_RSA_WITH_AES_128_GCM_SHA256,TLS_RSA_WITH_3DES_EDE_CBC_SHA,TLS_RSA_WITH_NULL_SHA256,TLS_RSA_WITH_NULL_SHA,TLS_PSK_WITH_AES_256_GCM_SHA384,TLS_PSK_WITH_AES_128_GCM_SHA256,TLS_PSK_WITH_AES_256_CBC_SHA384,TLS_PSK_WITH_AES_128_CBC_SHA256,TLS_PSK_WITH_NULL_SHA384,TLS_PSK_WITH_NULL_SHA256" -Type String -Force
# Prioritize ECC Curves with longer keys - IISCrypto (recommended options)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002" -Name EccCurves -Value @("NistP384","NistP256") -Type MultiString -Force
# OCSP stapling - Enabling this registry key has a potential performance impact
# Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" -Name EnableOcspStaplingForSni -Value 1 -Type DWord -Force
# Enabling Strong Authentication for .NET Framework
$netFrameworkPaths = @(
    "HKLM:\SOFTWARE\Microsoft\.NETFramework\v2.0.50727",
    "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v2.0.50727",
    "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319",
    "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v4.0.30319"
)
foreach ($path in $netFrameworkPaths) {
    Set-ItemProperty -Path $path -Name SchUseStrongCrypto -Value 1 -Type DWord -Force
    Set-ItemProperty -Path $path -Name SystemDefaultTlsVersions -Value 1 -Type DWord -Force
}



# Enable and Configure Edge Internet Browser Settings
# Prevent Edge from running in background
New-Item -Path "HKLM:\Software\Policies\Microsoft\Edge" -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "BackgroundModeEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Enable SmartScreen for Edge
New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter" -Force | Out-Null
New-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -Value 1 -PropertyType DWORD -Force | Out-Null

# Enable Notifications in IE when a site attempts to install software
New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Installer" -Force | Out-Null
New-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Installer" -Name "SafeForScripting" -Value 0 -PropertyType DWORD -Force | Out-Null

# Disable Edge password manager to encourage use of proper password manager
New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" -Force | Out-Null
New-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main" -Name "FormSuggest Passwords" -Value "no" -PropertyType String -Force | Out-Null

# More hardening
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "SitePerProcess" -Value 1 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "SSLVersionMin" -Value "tls1.2^@" -PropertyType String -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "NativeMessagingUserLevelHosts" -Value 0 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "SmartScreenEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "PreventSmartScreenPromptOverride" -Value 1 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "PreventSmartScreenPromptOverrideForFiles" -Value 1 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "SSLErrorOverrideAllowed" -Value 0 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "SmartScreenPuaEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null
New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Edge" -Name "AllowDeletingBrowserHistory" -Value 0 -PropertyType DWORD -Force | Out-Null

# Enable and Configure Google Chrome Internet Browser Settings
# Configure Google Chrome Internet Browser Settings

# Advanced Protection Allowed
New-Item -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Force | Out-Null
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AdvancedProtectionAllowed" -Value 1 -PropertyType DWORD -Force | Out-Null

# Allow Cross-Origin Auth Prompt
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AllowCrossOriginAuthPrompt" -Value 0 -PropertyType DWORD -Force | Out-Null

# Always Open PDF Externally
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AlwaysOpenPdfExternally" -Value 0 -PropertyType DWORD -Force | Out-Null

# Ambient Authentication In Private Modes Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AmbientAuthenticationInPrivateModesEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Audio Capture Allowed
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AudioCaptureAllowed" -Value 1 -PropertyType DWORD -Force | Out-Null

# Audio Sandbox Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AudioSandboxEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null

# Block External Extensions
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "BlockExternalExtensions" -Value 1 -PropertyType DWORD -Force | Out-Null

# SSL Version Minimum
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "SSLVersionMin" -Value "tls1.2" -PropertyType String -Force | Out-Null

# Screen Capture Allowed
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "ScreenCaptureAllowed" -Value 1 -PropertyType DWORD -Force | Out-Null

# Site Per Process
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "SitePerProcess" -Value 1 -PropertyType DWORD -Force | Out-Null

# TLS 1.3 Hardening For Local Anchors Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "TLS13HardeningForLocalAnchorsEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null

# Video Capture Allowed
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "VideoCaptureAllowed" -Value 1 -PropertyType DWORD -Force | Out-Null

# Allow File Selection Dialogs
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AllowFileSelectionDialogs" -Value 1 -PropertyType DWORD -Force | Out-Null

# Autofill Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AutoFillEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Autofill Address Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AutofillAddressEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Autofill Credit Card Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AutofillCreditCardEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Password Manager Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "PasswordManagerEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Metrics Reporting Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "MetricsReportingEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Import Saved Passwords
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "ImportSavedPasswords" -Value 0 -PropertyType DWORD -Force | Out-Null

# Cloud Print Submit Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "CloudPrintSubmitEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Cloud Print Proxy Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "CloudPrintProxyEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Allow Outdated Plugins
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AllowOutdatedPlugins" -Value 0 -PropertyType DWORD -Force | Out-Null

# Alternate Error Pages Enabled
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "AlternateErrorPagesEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# DNS Over HTTPS Mode
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "DnsOverHttpsMode" -Value "automatic" -PropertyType String -Force | Out-Null

# DNS Over HTTPS Templates
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "DnsOverHttpsTemplates" -Value "https://1.1.1.2/dns-query" -PropertyType String -Force | Out-Null

# Network Service Sandbox
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "NetworkServiceSandbox" -Value 0 -PropertyType DWORD -Force | Out-Null


# Additional Google Chrome Internet Browser Settings

# Allow Outdated Plugins
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "AllowOutdatedPlugins" -Value 0 -PropertyType DWORD -Force | Out-Null

# Alternate Error Pages Enabled
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "AlternateErrorPagesEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Block Third Party Cookies
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "BlockThirdPartyCookies" -Value 1 -PropertyType DWORD -Force | Out-Null

# Import Autofill Form Data
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "ImportAutofillFormData" -Value 0 -PropertyType DWORD -Force | Out-Null

# URL Keyed Anonymized Data Collection Enabled
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "UrlKeyedAnonymizedDataCollectionEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# WebRTC Event Log Collection Allowed
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "WebRtcEventLogCollectionAllowed" -Value 0 -PropertyType DWORD -Force | Out-Null

# Safe Browsing Protection Level
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "SafeBrowsingProtectionLevel" -Value 2 -PropertyType DWORD -Force | Out-Null

# Background Mode Enabled
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "BackgroundModeEnabled" -Value 0 -PropertyType DWORD -Force | Out-Null

# Password Leak Detection Enabled
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "PasswordLeakDetectionEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null

# Remote Debugging Allowed
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "RemoteDebuggingAllowed" -Value 0 -PropertyType DWORD -Force | Out-Null

# User Feedback Allowed
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "UserFeedbackAllowed" -Value 0 -PropertyType DWORD -Force | Out-Null

# DNS Interception Checks Enabled
New-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome" -Name "DNSInterceptionChecksEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null
