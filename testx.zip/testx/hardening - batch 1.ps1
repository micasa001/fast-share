#ensure maximum password age
Write-Host "[+] Setting max password age to 30"
net accounts /maxpwage:30

#ensure minimum password age
Write-Host "[+] Setting min password age to 1"
net accounts /minpwage:1

#ensure minimum password length is 14 characters
Write-Host "[+] Setting min password length to 14"
net accounts /minpwlen:14

Write-host "[+] Setting lockout threshold to 5"
net accounts /lockoutthreshold:5

Write-host "[+] Setting lockout windows to 10"
net accounts /lockoutwindow:10

#ensure password history is 24
Write-host "[+] Setting password history to 24"
net accounts /uniquepw:24

#ensure 'Accounts:Administrator account status' is Enabled
#Write-host "[+] Setting administrator account status to ON"
#net user administrator /active:yes