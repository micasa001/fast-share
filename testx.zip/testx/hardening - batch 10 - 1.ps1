# Enable DNS over HTTPS (DoH)
$PhysAdapter = Get-NetAdapter -Physical
$PhysAdapter | Get-DnsClientServerAddress -AddressFamily IPv4 | Set-DnsClientServerAddress -ServerAddresses '1.1.1.1','8.8.8.8'
