
### CMD Hardening

# Change file associations to protect against common ransomware attacks
# Note that if you legitimately use these extensions, like .bat, you will now need to execute them manually from PowerShell
# Alternatively, you can right-click on them and hit 'Run as Administrator' but ensure it's a script you want to run :) 

# Changing back example (x64):
# Set-ItemProperty -Path HKCR\htafile.mscfile -Name DelegateExecute -Value "" -PropertyType String


# Prevent Local windows wireless exploitation: the Airstrike attack
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\System -Name DontDisplayNetworkSelectionUI -PropertyType DWORD -Value 1 -Force

# Note: Mitigating ClickOnce .appref-ms files requires additional research  
# reg delete "HKLM\SOFTWARE\Classes\.appref-ms" /f

Write-Host "File associations have been changed. Some programs may need to be launched manually from PowerShell."

Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" DisableCompression -Type DWORD -Value 1 -Force
New-ItemProperty -Path 'HKLM:\Software\Microsoft\OLE' -Name 'EnableDCOM' -PropertyType DWORD -Value 0 -Force
