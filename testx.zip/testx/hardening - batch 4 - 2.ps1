# Enable Windows Defender Application Guard for Microsoft Edge
# This setting is commented out as it enables subset of DC/CG which renders other virtualization products unsuable. Can be enabled if you don't use those
# Enable-WindowsOptionalFeature -online -FeatureName Windows-Defender-ApplicationGuard -norestart
# Dism /online /Enable-Feature /FeatureName:"Windows-Defender-ApplicationGuard"

# Enable Windows Defender Credential Guard / Core Isolation
# https://old.reddit.com/r/virtualbox/comments/e4khzp/core_isolation_incompatibility/
# This setting is commented out as it enables subset of DC/CG which renders other virtualization products like VMWare, Virtualbox and HypeV unsuable.
# reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v EnableVirtualizationBasedSecurity /t REG_DWORD /d 1 /f
# reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v RequirePlatformSecurityFeatures /t REG_DWORD /d 3 /f
# reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v LsaCfgFlags /t REG_DWORD /d 1 /f

# Enable Network protection
# Enabled - Users will not be able to access malicious IP addresses and domains
# Disable (Default) - The Network protection feature will not work. Users will not be blocked from accessing malicious domains
# AuditMode - If a user visits a malicious IP address or domain, an event will be recorded in the Windows event log but the user will not be blocked from visiting the address.
Set-MpPreference -EnableNetworkProtection Enabled 