# All hotcakex Optional Windows Features

# Define feature names for easier reference
$featuresToDisable = @(
  "Windows PowerShell v2.0",
  "Work Folders Client",
  "Internet Printing Client",
  "Windows Media Player",
  "Microsoft Defender Application Guard",
  "Notepad",
  "VBScript",
  "Internet Explorer 11",
  "Client for Microsoft Networks", # Disables WMIC
  "Wordpad",
  "Windows PowerShell ISE",
  "Steps Recorder"
)

$featureToEnableSandbox = "Windows Sandbox"
$featureToEnableHyperV = "Hyper-V"

# Function to disable a feature by name
function Disable-Feature {
  param(
    [string] $featureName
  )
  
  $keyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Features\Components"
  $valueName = "$featureName"
  
  # Check if feature key exists
  if (Test-Path -Path "$keyPath\$valueName") {
    # Set value to 0 (disabled)
    Set-ItemProperty -Path "$keyPath\$valueName" -Name "EnabledState" -Value 0
    Write-Host "Disabled feature: $featureName"
  } else {
    Write-Warning "Feature not found: $featureName"
  }
}

# Disable all features in the list
foreach ($feature in $featuresToDisable) {
  Disable-Feature -featureName $feature
}

# Enable Windows Sandbox
$keyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Features\Components"
$valueName = "$featureToEnableSandbox"

if (Test-Path -Path "$keyPath\$valueName") {
  Set-ItemProperty -Path "$keyPath\$valueName" -Name "EnabledState" -Value 1
  Write-Host "Enabled feature: $featureToEnableSandbox"
} else {
  Write-Warning "Feature not found: $featureToEnableSandbox (May require additional installation steps)"
}

# Enable Hyper-V (may require additional configuration)
$keyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\FeatureManagement\Features\Hyper-V"
$valueName = "EnabledState"

if (Test-Path -Path "$keyPath\$valueName") {
  Set-ItemProperty -Path "$keyPath\$valueName" -Name $valueName -Value 1
  Write-Host "Enabled feature: $featureToEnableHyperV (May require additional configuration)"
} else {
  Write-Warning "Feature not found: $featureToEnableHyperV (May require additional installation steps)"
}

# Note: This script modifies the registry. Back up the registry before running it.
