
# Windows hardening controls

# This are all the hotcake fixes from the module. Goal is to integrate all settings within 1 hardening solution.

############### Microsoft Defender Category

# Set Enhanced Phishing Protection settings
Set-MpPreference -EnhancedMpRegKey "EnableEnhancedPhishingProtection" -Value 1
Set-MpPreference -EnhancedMpRegKey "EnablePhishingPhishingNotification" -Value 1
Set-MpPreference -EnhancedMpRegKey "EnablePhishingUrlNotification" -Value 1
Set-MpPreference -EnhancedMpRegKey "EnablePhishingThreatNotification" -Value 1
Set-MpPreference -EnhancedMpRegKey "EnablePhishingCaptureWindow" -Value 1

# Set detection and scan settings
Set-MpPreference -ScanType PUA -Enabled $true  # Enable detection for potentially unwanted applications
Set-MpPreference -CloudScanTime -Value 50      # Set extended cloud check to 50 seconds
Set-MpPreference -ScanMaxFileSize -Value 10000000  # Set maximum scan file size to 10MB
Set-MpPreference -DisableRealtimeScanning -Value $false  # Enable Real-time scanning (assuming you want it on)
Set-MpPreference -DisableScheduledScan -Value $false  # Enable Scheduled scanning (assuming you want it on)
Set-MpPreference -RemediationActionForSevereThreats -Value 3  # Set severe threat action to remove
Set-MpPreference -RemediationActionForHighThreats -Value 3  # Set high threat action to remove
Set-MpPreference -RemediationActionForMediumThreats -Value 2  # Set medium threat action to quarantine
Set-MpPreference -RemediationActionForLowThreats -Value 2  # Set low threat action to quarantine

# Set Controlled Folder Access and Network Protection
Set-MpPreference -EnableControlledFolderAccess -Value $true
Set-MpPreference -EnableNetworkProtection -Value $true

# Configure other settings (modify based on your needs)
Set-MpPreference -SigUpdateInterval -Value 3  # Set interval to check for security intelligence updates to 3 hours
# Not recommended to disable following:
# Set-MpPreference -DisableAutomaticUpdates -Value $true  # Disable automatic updates (not recommended)
Set-MpPreference -SecurityIntelligenceUpdateOnStartup -Value 1  # Enable security intelligence update on startup

# Enable specific process mitigations (replace process names with desired ones)
Set-ProcessMitigation -Name WINWORD.EXE -Enable StrictHandle, DisableInheritableHandles
Set-ProcessMitigation -Name MSACCESS.EXE -Enable StrictHandle, DisableInheritableHandles
# ... Add mitigations for other processes following the same format

# Enable Restore Point scanning
Set-MpPreference -EnableRemediationOnScan -Value $true

# Enable Brute Force Protection (assuming you want aggressive mode)
Set-BedDetection -ForceLockoutMode Aggressive
Set-BedDetection -Enabled $true

# Enable Remote Encryption Protection (assuming you want high aggressiveness)
Set-MpPreference -EnableRemoteBlock -Value $true
Set-MpPreference -RemoteBlockAggressiveLevel -Value 2

# Note: Script doesn't cover all settings you provided (Controlled Folder Access exclusions, specific features)

# Write a message upon completion
Write-Host "Configured some Windows Defender settings!"





############### Attack Surface Reduction Rules Category

# Configure Attack Surface Reduction Rules Category

# Enable Attack Surface Reduction rules
Set-MpPreference -AttackSurfaceReductionRules_Ids @(
    '5678be24-ba6e-4b06-b3d9-3b5b06d63ebf', # Configure Attack Surface Reduction rules
    'ba8731fd-8963-47e8-aefc-ad26bcb0103b', # Block executable files from running unless they meet a prevalence; age or trusted list criterion
    'd4f940ab-401b-4efc-aadc-ad5f3c50688a', # Block Adobe Reader from creating child processes
    '3b576869-a4ec-4529-8536-b80a7769e899', # Block untrusted and unsigned processes that run from USB
    '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84', # Block Office communication application from creating child processes
    'd3e037e1-3eb8-44c8-a917-57927947596d', # Block JavaScript or VBScript from launching downloaded executable content
    '8142b780-036a-4dc4-987e-dcb1be9f4a7e', # Block rebooting machine in Safe Mode
    '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2', # Block process creations originating from PSExec and WMI commands
    '1b4e3fe6-3a60-4b3e-b9a9-33a3ef7e5ea7', # Use advanced protection against ransomware
    'd4f940ab-401b-4efc-aadc-ad5f3c50688a', # Block executable content from email client and webmail
    'c1db55ab-c21a-4637-bb3f-a12568109d35', # Block abuse of exploited vulnerable signed drivers
    'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550', # Block execution of potentially obfuscated scripts
    'cc5e8a82-4d6f-48e8-afe9-3cbf54592427', # Block use of copied or impersonated system tools
    '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2', # Block credential stealing from the Windows local security authority subsystem (lsass.exe)
    '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84', # Block Office applications from creating executable content
    'd3e037e1-3eb8-44c8-a917-57927947596d', # Block Win32 API calls from Office macros
    '2d5d1d36-5351-4d9d-86bc-134051981507', # Block persistence through WMI event subscription
    'c1db55ab-c21a-4637-bb3f-a12568109d35'  # Block Office applications from injecting code into other processes
    'd4f940ab-401b-4efc-aadc-ad5f3c50688a'  # Block all Office applications from creating child processes
) -AttackSurfaceReductionRules_Actions @(
    'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled', 'Enabled'
)

# Set individual rule settings
$ASRSettings = @{
    "Extension" = ".exe";
    "PrevalenceFilePath" = "";
    "Prevalence" = 60;
    "AgeFilePath" = "";
    "Age" = 30;
    "ProtectedFolders" = "";
    "TrustedListFilePath" = "";
}

# Block executable files from running unless they meet a prevalence; age or trusted list criterion
Set-MpPreference -AttackSurfaceReductionRules_Ids 'ba8731fd-8963-47e8-aefc-ad26bcb0103b' -AttackSurfaceReductionRules_Actions 'Enabled' -AttackSurfaceReductionRules_ExtraParameters $ASRSettings

# Repeat the above process for each setting with their respective values...

# continue for each setting




############### TLS Category

# Configure the correct TLS Cipher Suites
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\TLS 1.2\TLS_CHACHA20_POLY1305_SHA256' -Name 'Enabled' -Value 1
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\TLS 1.2\TLS_AES_256_GCM_SHA384' -Name 'Enabled' -Value 1
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\TLS 1.2\TLS_AES_128_GCM_SHA256' -Name 'Enabled' -Value 1

# ECC Curves and their positions
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -Name 'Enabled' -Value 1
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -Name 'ClientECCCurves' -Value 'nistP521,curve25519,NistP384,NistP256'

# Disable TLS 1.0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Name 'Enabled' -Value 0

# Disable TLS 1.1
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Name 'Enabled' -Value 0

# Disable NULL Cipher Suite
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\NULL' -Name 'Enabled' -Value 0

# Disable weak Cipher Suites
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\DES 56/56' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 56/128' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC2 128/128' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 40/128' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 56/128' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 64/128' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 128/128' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168' -Name 'Enabled' -Value 0

# Disable MD5 Hashing Algorithm
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -Name 'Enabled' -Value 0



############### User Account Control Category


# Set UAC settings
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "HideFastUserSwitching" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin" -Value 2
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorUser" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ValidateAdminCodeSignatures" -Value 0



############### Device Guard Category

# Enable Virtualization Based Security
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "EnableVirtualizationBasedSecurity" -Value 1

# Require Platform Security Features
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "RequirePlatformSecurityFeatures" -Value 1

# Hypervisor Enforced Code Integrity
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "HypervisorEnforcedCodeIntegrity" -Value 1

# Require HVCI MAT (Memory Attribute Table)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "RequireHVCIMAT" -Value 1

# Credential Guard Configuration
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "CredentialGuardEnabled" -Value 1

# Configure System Guard Launch
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "SystemGuardSecureLaunch" -Value 1

# Configure Kernel Shadow Stacks Launch
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "KernelVirtualAddressShadow" -Value 1

# Enable Local Security Authority (LSA) process Protection with UEFI Lock
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\LSA" -Name "RunAsPPL" -Value 1






############### Windows Firewall Category

# Windows Firewall instellingen
# Schakel Windows Firewall in
Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True

# Stel standaard uitgaande actie in voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -DefaultOutboundAction Block

# Stel standaard inkomende actie in voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -DefaultInboundAction Block

# Blokkeer alle verbindingen voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -BlockAllInbound

# Stel logboekbestandspad in voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -LogFileName %systemroot%\system32\logfiles\firewall\domainfirewall.log

# Stel logboekbestandsgrootte in voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -LogMaxSize 32767

# Log geblokkeerde verbindingen voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -LogBlocked True

# Log succesvolle verbindingen voor Domain-profiel
Set-NetFirewallProfile -Profile Domain -LogAllowed True

# Configureer logboekbestandsgrootte voor Private-profiel
Set-NetFirewallProfile -Profile Private -LogMaxSize 32767

# Log geblokkeerde verbindingen voor Private-profiel
Set-NetFirewallProfile -Profile Private -LogBlocked True

# Stel logboekbestandspad in voor Private-profiel
Set-NetFirewallProfile -Profile Private -LogFileName %systemroot%\system32\logfiles\firewall\privatefirewall.log

# Configureer logboekbestandsgrootte voor Public-profiel
Set-NetFirewallProfile -Profile Public -LogMaxSize 32767

# Log geblokkeerde verbindingen voor Public-profiel
Set-NetFirewallProfile -Profile Public -LogBlocked True

# Stel logboekbestandspad in voor Public-profiel
Set-NetFirewallProfile -Profile Public -LogFileName %systemroot%\system32\logfiles\firewall\publicfirewall.log

# Schakel mDNS UDP-In Firewall-regels uit
Set-NetFirewallRule -DisplayName "mDNS UDP-In" -Enabled False





############### Optional Windows Features Category

# Disable PowerShell v2
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\PowerShell" -Name "EnableScripts" -Value 0

# Disable Work Folders client
Disable-WindowsOptionalFeature -Online -FeatureName "WorkFolders-Client"

# Disable Internet Printing Client
Disable-WindowsOptionalFeature -Online -FeatureName "Printing-XPSServices-Features"

# Disable Windows Media Player (legacy)
Disable-WindowsOptionalFeature -Online -FeatureName "WindowsMediaPlayer"

# Enable Microsoft Defender Application Guard
Enable-WindowsOptionalFeature -Online -FeatureName "Containers-DisposableClientVM"

# Enable Windows Sandbox
Enable-WindowsOptionalFeature -Online -FeatureName "Containers-DisposableClientVM"

# Enable Hyper-V
Enable-WindowsOptionalFeature -Online -FeatureName "Microsoft-Hyper-V-All"

# Remove WMIC (Windows Management Instrumentation Command-line)
Remove-Item -Path "C:\Windows\System32\wbem\WMIC.exe"

# Remove Internet Explorer mode functionality for Edge
Remove-Item -Path "C:\Program Files (x86)\Microsoft\Edge\Application\*\Internet Explorer"

# Remove Legacy Notepad
Remove-Item -Path "C:\Windows\System32\notepad.exe"

# Remove WordPad
Remove-Item -Path "C:\Program Files\Windows NT\Accessories\wordpad.exe"

# Remove PowerShell ISE
Remove-Item -Path "C:\Windows\System32\WindowsPowerShell\v1.0\powershell_ise.exe"

# Remove Steps Recorder
Remove-Item -Path "C:\Windows\System32\psr.exe"




############### Windows Networking Category

# Disable Netbios
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "EnableNetbios" -Value 0

# Disable Smart Name Resolution
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" -Name "SmartResolutionEnabled" -Value 0

# Disable Multicast
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "EnableMulticast" -Value 0

# Disable HTTP Printing
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "EnableHTTPPrint" -Value 0

# Disable Web PnP Download
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "NoWarningNoElevationOnInstall" -Value 1

# Network Location of all connections set to Public
Set-NetConnectionProfile -AllNetworks -NetworkCategory Public

# Disable LMHOSTS lookup protocol on all network adapters
Get-NetAdapter | Set-NetAdapterAdvancedProperty -DisplayName "LMHOSTS Lookup" -DisplayValue "Disabled"

# Network access: Remotely accessible registry paths
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths" -Name "Machine" -Value ""

# Network access: Remotely accessible registry paths and subpaths
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths" -Name "Machine" -Value "*"

# Display the updated settings
Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" | Select-Object EnableNetbios
Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" | Select-Object SmartResolutionEnabled
Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" | Select-Object EnableMulticast
Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" | Select-Object EnableHTTPPrint
Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" | Select-Object NoWarningNoElevationOnInstall
Get-NetConnectionProfile | Select-Object Name, NetworkCategory
Get-NetAdapterAdvancedProperty -Name * | Where-Object {$_.DisplayName -eq "LMHOSTS Lookup"}
Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths" | Select-Object Machine



############### Miscellaneous Category

# Miscellaneous Category Settings

# Enable command line logging in process creation events
Set-WinEvent -LogName System -ProviderName Microsoft-Windows-Security-WinProcessMonitoring -FilterXPath "*[System [EventRecord]::Level = 4]" | Out-Null

# Disable Location services
Set-LocationService -Status Disabled

# Disable Location Scripting
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\NlaSvc -Name Start -Value 4 -Type DWORD

# Disable Windows Location Provider
Set-Service -Name geolocation -Status Disabled

# Enable RPC Endpoint Mapper Client Authentication
Set-NetFirewallRule -Name "RPC Endpoint Mapper (TCP-In)" -RemoteAddress Any -AuthRequired True

# Enable Svchost Mitigation
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management -Name LpfnStartProcess -PropertyType String -Value "%SystemRoot%\System32\csrss.exe"

# Set Boot-Start Driver Initialization Policy
BCDEdit /set {current} loadoptions DDISABLE_INTEGRITY_CHECKS

# Enable Audit policy for Other Logon/Logoff Events
Get-WinEvent -LogName Security -List | Where-Object {$_.ProviderName -eq "Microsoft-Windows-Security-Auditing"} | ForEach-Object {Set-WinEvent -LogName Security -ProviderName $_.ProviderName -FilterXPath "Event/@*[SystemName='Security']/Event/@*[System [EventRecord]::Opcode = '4' or System [EventRecord]::Opcode = '5']" | Out-Null}

# Hyper-V Administrators group check (manual verification recommended)
# This script cannot modify group membership directly. Check if all users are members and add them if necessary using Net Local Group

# Enable enhanced search in Windows
Set-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name Advanced -PropertyType DWORD -Value 0x8000000

# Set Microsoft Edge update behavior over Metered connections (requires administrative privileges)
# This script cannot modify update settings directly due to limitations. 
# Consider using Group Policy or manual configuration for updates.

# Change Windows time sync interval
Set-TimeSyncProvider -Name W32Time -Enabled True -ReliableTimeSource 0 -UpdateInterval 345600

# Enable SMB Encryption (requires additional configuration)
# This script cannot enable SMB encryption directly. 
# Refer to Microsoft documentation for configuration steps https://learn.microsoft.com/en-us/windows-server/storage/file-server/smb-security

# WinVerifyTrust Signature Validation (limited script capabilities)
# This script cannot directly modify these settings. Refer to Microsoft documentation for configuration steps.

Write-Host "Script execution completed. Please review manual verification steps and additional configuration notes."




############### Windows Update Category


# Configure Automatic Update settings
$AUOptions = 4  # Allow downloads over metered connections

# Automatic update deadlines (True enables deadlines)
$EnableDeadlines = $True

# Deadlines (set to 0 for immediate install)
$QualityUpdateAutomaticInstallDays = 0
$QualityUpdateGracePeriodDays = 1
$FeatureUpdateAutomaticInstallDays = 0
$FeatureUpdateGracePeriodDays = 1

# Download and install settings
$DownloadOption = 4  # Download updates and install on maintenance day
$InstallDuringMaintenance = 1  # Install updates during maintenance
$ScheduledInstallDay = 0  # Every day
$ScheduledInstallTime = 24  # Any time
$UpdateOtherProducts = 1  # Install updates for other Microsoft products
$EnableRestartNotification = $True  # Enable restart notification

# Set Automatic Updates registry key
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name AUOptions -Value $AUOptions

# Enable deadlines if desired
if ($EnableDeadlines) {
  New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name UseAutomaticUpdates -PropertyType DWORD -Value 1
} else {
  Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name UseAutomaticUpdates -Force
}

# Set deadlines (0 for immediate install)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name QAutomaticInstallDays -Value $QualityUpdateAutomaticInstallDays
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name QAutomaticInstallNight -Value 0  # Install any time
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name QGracePeriodDays -Value $QualityUpdateGracePeriodDays

Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name ScheduledInstallDay -Value $ScheduledInstallDay
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name ScheduledInstallTime -Value $ScheduledInstallTime

# Configure Automatic Update service settings
Set-WUSettings -AutomaticDownloadMode $DownloadOption
Set-WUSettings -InstallDuringMaintenance $InstallDuringMaintenance
Set-WUSettings -UpdateMopOtherProducts $UpdateOtherProducts
Set-WUSettings -AutoRebootAtScheduledTime $EnableRestartNotification

# Force policy refresh (might require reboot for full effect)
gpupdate /force




############### Microsoft Edge-instellingen

# Block 3rd party cookies
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "Block3rdPartyCookies" -Value 1 -Type DWORD

# Set Dns Over Https Mode to use system DoH settings
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "DnsOverHttpsMode" -Value "automatic" -Type String

# Automatically upgrade HTTP connections to HTTPS
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "ForceHttps" -Value 2 -Type DWORD

# Enable Encrypted Client Hello
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "EnableEncryptedClientHello" -Value 1 -Type DWORD

# Block Basic authentication for HTTP
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "BlockBasicAuth" -Value 0 -Type DWORD

# Allow Edge to receive new features even after using policies
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "AllowMicrosoftEdgeSideBySide" -Value 2 -Type DWORD

# Enforces the audio process to run sandboxed
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "SandboxAudio" -Value 1 -Type DWORD

# Recommends that the share additional operating system region setting to be set to never
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "ShareSettingsAdditionalRegion" -Value 2 -Type DWORD

# Disable TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA - (CBC - SHA1)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "TlsEcdheRsaWithAes128CbcSha" -Value 0xc013 -Type DWORD

# Disable TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA - (CBC - SHA1)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "TlsEcdheRsaWithAes256CbcSha" -Value 0xc014 -Type DWORD

# Disable TLS_RSA_WITH_AES_256_CBC_SHA - (NO PFS - CBC - SHA1)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "TlsRsaWithAes256CbcSha" -Value 0x0035 -Type DWORD

# Disable TLS_RSA_WITH_AES_128_CBC_SHA - (NO PFS - CBC - SHA1)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "TlsRsaWithAes128CbcSha" -Value 0x002f -Type DWORD

# Disable TLS_RSA_WITH_AES_128_GCM_SHA256 - (NO PFS)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "TlsRsaWithAes128GcmSha256" -Value 0x009c -Type DWORD

# Disable TLS_RSA_WITH_AES_256_GCM_SHA384 - (NO PFS)
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "TlsRsaWithAes256GcmSha384" -Value 0x009d -Type DWORD





############### Non admin category

# Set Show File extensions
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "HideFileExt" -Value 0

# Set Show hidden files
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Hidden" -Value 1

# Disable websites accessing local language list
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Name "1200" -Value 1

# Turn off safe search in Windows search
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SafeSearch" -Value 0

# Enable Clipboard History
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Clipboard" -Name "EnableClipboardHistory" -Value 1

# Enable sync of Clipboard history in Windows between devices
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Clipboard" -Name "RoamingClipboard" -Value 1

# Enable Clipboard sync
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Clipboard" -Name "SyncAcrossDevices" -Value 1

# Turn on Show text suggestions when typing on the physical keyboard
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Input\TIPC" -Name "EnableMultilingualFeatures" -Value 1

# Turn on Multilingual text suggestions
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Input\TIPC" -Name "EnableMultilingualSupport" -Value 1

# Turn off sticky key shortcut of pressing shift key 5 times fast
Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" -Name "Flags" -Value 506

# Disable show reminders and incoming VoIP calls on the lock screen
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative" -Name "ContentDeliveryAllowed" -Value 0
